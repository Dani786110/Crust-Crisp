CRUST & CRISP — FREE ORDERING WEBSITE

Your app is a mobile-friendly ordering website. Customers can add menu items,
enter their details, and send the order to WhatsApp number 03192099092.

MENU:
Pizza — PKR 850
Potato Twister — PKR 50
Potato Fries — PKR 50–100
Pizza Bite — PKR 250
Loaded Fries — PKR 280
Pizza Fries — PKR 350

HOW TO PUT IT ONLINE FOR FREE:
1. Create a free GitHub account at github.com.
2. Create a new repository named: crust-and-crisp
3. Upload index.html to that repository.
4. Open Settings → Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select the main branch and folder "/ (root)", then Save.
7. GitHub will give you a website link.
8. Open that link on your phone. You can use "Add to Home screen" in Chrome.

IMPORTANT:
- WhatsApp ordering is already set to 03192099092.
- Potato Fries currently displays PKR 50–100, but the order button uses PKR 50.
  If you want separate Small/Regular/Large options, tell me and I can update it.
